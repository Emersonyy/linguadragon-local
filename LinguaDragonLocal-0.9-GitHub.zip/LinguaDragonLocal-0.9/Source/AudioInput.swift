import AVFoundation

enum AudioSource:String,CaseIterable,Identifiable {
 case system, microphone
 var id:String { rawValue }
 var title:String { self == .system ? "系统音频" : "麦克风" }
 var hint:String { self == .system ? "听电脑播放的会议或视频；开始时选择共享音源。" : "听周围声音；设备在系统设置 → 声音 → 输入中选择。首次需允许麦克风权限。" }
}
@MainActor final class AudioInput {
 private let system = SystemAudio()
 private let microphone = MicrophoneAudio()
 private var selected:AudioSource?
 var onBuffer: ((AVAudioPCMBuffer)->Void)?
 var onError: ((String)->Void)?
 var onLevel: ((Float)->Void)?
 func start(target:AVAudioFormat,source:AudioSource) async throws {
 await stop()
 selected = source
 do {
 switch source {
 case .system:
 system.onBuffer = onBuffer; system.onError = onError; system.onLevel = onLevel
 try await system.start(target:target)
 case .microphone:
 microphone.onBuffer = onBuffer; microphone.onError = onError; microphone.onLevel = onLevel
 try await microphone.start(target:target)
 }
 } catch { await stop(); throw error }
 }
 func stop() async {
 let previous = selected; selected = nil
 switch previous {
 case .system: await system.stop()
 case .microphone: await microphone.stop()
 case nil: break
 }
 }
}
