import Foundation
import PDFKit
import NaturalLanguage

// Extract only user-selected documents; never execute their contents.
enum KnowledgeFolder {
 private static let cacheLock = NSLock()
 private static var cache: [String: [Passage]] = [:]
 struct Passage { let file:String; let location:String; let text:String }
 static func tokens(_ text:String) -> Set<String> {
 let lower = text.lowercased()
 let tokenizer = NLTokenizer(unit:.word); tokenizer.string = lower
 var result = Set<String>()
 tokenizer.enumerateTokens(in:lower.startIndex..<lower.endIndex) { range,_ in
 let word = String(lower[range]); if word.count >= 2 { result.insert(word) }; return true
 }
 // CJK bigrams also match Chinese/Japanese compounds with different token boundaries.
 let chars = Array(lower)
 if chars.count > 1 { for i in 0..<(chars.count-1) {
 if chars[i].unicodeScalars.contains(where:{(0x3400...0x9fff).contains(Int($0.value))}) && chars[i+1].unicodeScalars.contains(where:{(0x3400...0x9fff).contains(Int($0.value))}) { result.insert(String(chars[i...i+1])) }
 } }
 return result
 }
 static func docx(_ url:URL) throws -> String {
 let process = Process(); process.executableURL = URL(fileURLWithPath:"/usr/bin/textutil")
 process.arguments = ["-convert","txt","-stdout",url.path]
 let pipe = Pipe(); process.standardOutput = pipe; process.standardError = FileHandle.nullDevice
 try process.run()
 // Limit extraction output and runtime, including malformed documents.
 let deadline = DispatchWorkItem { if process.isRunning { process.terminate() } }
 DispatchQueue.global().asyncAfter(deadline:.now()+10,execute:deadline)
 defer { deadline.cancel(); try? pipe.fileHandleForReading.close() }
 var data = Data()
 while let chunk = try pipe.fileHandleForReading.read(upToCount:65536), !chunk.isEmpty {
 data.append(chunk)
 if data.count > 2_000_000 { process.terminate(); break }
 }
 process.waitUntilExit()
 guard process.terminationStatus == 0, data.count <= 2_000_000, let text = String(data:data,encoding:.utf8) else { throw LocalFailure(message:"Word 文档提取失败或过大") }
 return text
 }
 static func read(_ root:URL?,query:String) throws -> KnowledgeExcerpt {
 guard let root else { return KnowledgeExcerpt(text:"未提供参考资料。",files:[],note:"未附带参考资料") }
 let base = root.resolvingSymlinksInPath().standardizedFileURL
 guard let iterator = FileManager.default.enumerator(at:base,includingPropertiesForKeys:[.isRegularFileKey,.fileSizeKey,.isSymbolicLinkKey,.contentModificationDateKey],options:[.skipsHiddenFiles,.skipsPackageDescendants]) else { throw LocalFailure(message:"参考资料文件夹无法访问，请重新选择。") }
 var passages:[Passage] = []; var warnings:[String] = []; var count = 0
 func append(_ text:String,file:String,location:String) {
 let chars = Array(text.prefix(300_000)); var offset = 0; var section = 1
 while offset < chars.count {
 let end = min(offset+1100,chars.count)
 let chunk = String(chars[offset..<end]).trimmingCharacters(in:.whitespacesAndNewlines)
 if !chunk.isEmpty { passages.append(Passage(file:file,location:location + " · 段\(section)",text:chunk)) }
 if end == chars.count { break }; offset = end-150; section += 1
 }
 }
 for case let url as URL in iterator {
 if ["node_modules","vendor","build","dist"].contains(url.lastPathComponent) { iterator.skipDescendants(); continue }
 guard ["md","txt","markdown","pdf","docx"].contains(url.pathExtension.lowercased()) else { continue }
 count += 1; if count > 100 { warnings.append("最多检查100个文件"); break }
 guard url.resolvingSymlinksInPath().standardizedFileURL.path.hasPrefix(base.path+"/") else { continue }
 let attrs = try? url.resourceValues(forKeys:[.isRegularFileKey,.fileSizeKey,.isSymbolicLinkKey,.contentModificationDateKey])
 guard attrs?.isRegularFile == true, attrs?.isSymbolicLink != true else { continue }
 let name = String(url.path.dropFirst(base.path.count+1))
 let maximumBytes = url.pathExtension.lowercased() == "pdf" ? 256_000_000 : 20_000_000
 guard (attrs?.fileSize ?? Int.max) <= maximumBytes else { warnings.append(name+"：超过\(maximumBytes / 1_000_000)MB，未读取"); continue }
 let cacheKey = url.path + "|" + String(attrs?.contentModificationDate?.timeIntervalSince1970 ?? 0) + "|" + String(attrs?.fileSize ?? 0)
 cacheLock.lock(); let cached = cache[cacheKey]; cacheLock.unlock()
 if let cached { passages += cached; if passages.count > 6000 { warnings.append("已限制本次索引量"); break }; continue }
 let before = passages.count
 do {
 if url.pathExtension.lowercased() == "pdf" {
 guard let pdf = PDFDocument(url:url), !pdf.isLocked else { throw LocalFailure(message:"PDF 无法打开或已加密") }
 for page in 0..<min(pdf.pageCount,2000) {
 try Task.checkCancellation()
 autoreleasepool { if let text = pdf.page(at:page)?.string { append(text,file:name,location:"第\(page+1)页") } }
 if passages.count >= 6000 { warnings.append(name+"：段落数量达到上限，读取至第\(page+1)页"); break }
 }
 if pdf.pageCount > 2000 { warnings.append(name+"：仅读取前2000页") }
 } else {
 let text = try url.pathExtension.lowercased() == "docx" ? docx(url) : String(contentsOf:url,encoding:.utf8)
 append(text,file:name,location:"正文")
 if text.count > 300_000 { warnings.append(name+"：仅读取前30万字符") }
 }
 let extracted = Array(passages.dropFirst(before))
 // Cache extracted text, never the PDF object; truncated files retain warnings on every read.
 if !extracted.isEmpty && extracted.count <= 6000 && warnings.isEmpty {
 cacheLock.lock()
 if cache.values.reduce(0,{$0 + $1.reduce(0,{$0 + $1.text.count})}) > 8_000_000 { cache.removeAll() }
 cache[cacheKey] = extracted; cacheLock.unlock()
 }
 if before == passages.count { warnings.append(name+"：没有可提取文字，扫描件请先做OCR") }
 } catch { warnings.append(name+"：读取失败") }
 if passages.count > 6000 { warnings.append("资料较多，已限制本次索引量"); break }
 }
 if passages.isEmpty { throw LocalFailure(message:"没有可用参考文字。" + (warnings.isEmpty ? "所选文件夹中没有支持的 PDF、DOCX、Markdown 或 TXT 文件。" : "\n" + warnings.prefix(8).joined(separator:"\n"))) }
 let terms = tokens(query)
 var scored: [(Int,Double)] = []
 for (index,p) in passages.enumerated() {
 let overlap = terms.isEmpty ? Set<String>() : terms.intersection(tokens(p.text))
 var score: Double = 0
 for word in overlap { score += Double(min(word.count,10)) }
 score += Double(terms.intersection(tokens(p.file)).count) * 3.0
 scored.append((index,score))
 }
 scored.sort { left,right in left.1 == right.1 ? left.0 < right.0 : left.1 > right.1 }
 var text = ""; var names:[String] = []
 for (index,_) in scored.prefix(12) {
 let p = passages[index]; text += "\n--- \(p.file) [\(p.location)] ---\n\(p.text)\n"
 if !names.contains(p.file) { names.append(p.file) }
 }
 let note = "检索了 \(passages.count) 个资料段落，本次发送 \(min(12,passages.count)) 段；按关键词匹配，可能漏掉跨语言或同义表述。" + (warnings.isEmpty ? "" : "\n"+warnings.prefix(8).joined(separator:"\n"))
 return KnowledgeExcerpt(text:text.isEmpty ? "没有可提取的参考文字；不能声称读过资料。" : text,files:names,note:note)
 }
}
