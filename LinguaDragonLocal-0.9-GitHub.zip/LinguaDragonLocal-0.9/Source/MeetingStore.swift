import Foundation
import AppKit
import CoreText

struct MeetingProject: Codable {
 var version = 1
 var id = UUID()
 var name: String
 var created = Date()
 var updated = Date()
 var records: [Subtitle] = []
 var knowledgePath: String?
 var knowledgePurpose: String?
 var useKnowledge: Bool?
}
func meetingDate(_ date:Date, format:String) -> String {
 let f = DateFormatter(); f.locale = Locale(identifier:"zh_CN"); f.timeZone = TimeZone(identifier:"Asia/Tokyo"); f.dateFormat = format; return f.string(from:date)
}
@MainActor final class MeetingStore {
 var project: MeetingProject?
 var folder: URL?
 let root:URL
 init(root:URL = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Desktop/会议记录",isDirectory:true)) { self.root = root }
 static func safeName(_ name:String) -> String {
 let cleaned = name.components(separatedBy:CharacterSet(charactersIn:"/:\\\n\r\t\0")).joined(separator:" ").trimmingCharacters(in:.whitespacesAndNewlines)
 let result = String(cleaned.prefix(70)); return result.isEmpty || result == "." || result == ".." ? "未命名会议" : result
 }
 func create(name:String) throws {
 try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
 let safe = Self.safeName(name); var candidate = root.appendingPathComponent(safe,isDirectory:true); var n = 2
 while FileManager.default.fileExists(atPath:candidate.path) { candidate = root.appendingPathComponent("\(safe) (\(n))",isDirectory:true); n += 1 }
 try FileManager.default.createDirectory(at:candidate,withIntermediateDirectories:false)
 let previous = project; let previousFolder = folder
 project = MeetingProject(name:safe); folder = candidate
 do { try save() } catch { project = previous; folder = previousFolder; throw error }
 }
 func open(_ folder:URL) throws {
 let data = try Data(contentsOf:folder.appendingPathComponent("会议工程.json"))
 let value = try JSONDecoder().decode(MeetingProject.self,from:data)
 guard value.version == 1 else { throw LocalFailure(message:"这个工程的版本暂不支持。") }
 self.project = value; self.folder = folder
 }
 func upsert(_ record:Subtitle) throws {
 guard project != nil else { return }
 if let index = project!.records.firstIndex(where:{$0.id == record.id}) { project!.records[index] = record } else { project!.records.append(record) }
 try save()
 }
 func save() throws {
 guard project != nil, let folder else { return }; project!.updated = Date()
 let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted,.sortedKeys]
 try encoder.encode(project!).write(to:folder.appendingPathComponent("会议工程.json"),options:.atomic)
 }
 func export() throws -> URL? {
 guard let project, let folder else { return nil }
 try save()
 let destination = folder.appendingPathComponent("会议文字记录.pdf")
 try MeetingPDF.write(project,to:destination)
 return destination
 }
}

enum MeetingPDF {
 static func write(_ project:MeetingProject,to url:URL) throws {
 let body = NSMutableAttributedString(string:"")
 var blocks:[NSRange] = []
 func append(_ text:String,size:CGFloat = 11,bold:Bool = false,color:NSColor = .black,spacing:CGFloat = 7) {
 let paragraph = NSMutableParagraphStyle(); paragraph.lineSpacing = 5; paragraph.paragraphSpacing = spacing
 body.append(NSAttributedString(string:text + "\n",attributes:[.font:bold ? NSFont.boldSystemFont(ofSize:size) : NSFont.systemFont(ofSize:size),.foregroundColor:color,.paragraphStyle:paragraph]))
 }
 append(project.name,size:23,bold:true,color:NSColor(calibratedRed:0.14,green:0.30,blue:0.44,alpha:1),spacing:13)
 append("创建：\(meetingDate(project.created,format:"yyyy-MM-dd HH:mm"))    导出：\(meetingDate(Date(),format:"yyyy-MM-dd HH:mm"))    时区：日本标准时间",size:9,color:.darkGray)
 append("共 \(project.records.count) 段 · 原文与中文译文 · 灵语龙会议记录",size:10,color:.darkGray,spacing:15)
 if project.records.isEmpty { append("本次会议尚无已记录的文字。") }
 for (index,record) in project.records.enumerated() {
 let blockStart = body.length
 append("\(index+1).  \(meetingDate(record.timestamp,format:"HH:mm:ss"))  ·  \(record.language.hasPrefix("ja") ? "日语" : "英语")\(record.provisional ? " · 未确认片段" : "")",size:10,bold:true,color:NSColor(calibratedRed:0.18,green:0.43,blue:0.62,alpha:1),spacing:4)
 append("原文：" + record.source,size:11,color:.darkGray,spacing:4)
 append("中文：" + record.chinese,size:12,spacing:record.error == nil ? 14 : 3)
 if let error = record.error { append("备注：" + error,size:9,color:.darkGray,spacing:14) }
 blocks.append(NSRange(location:blockStart,length:body.length-blockStart))
 }
 append("说明：本记录由语音识别及机器翻译生成，可能有误；请核对姓名、数字及重要决定。回复建议不作为实际发言记录。",size:9,color:.darkGray)
 let data = NSMutableData(); guard let consumer = CGDataConsumer(data:data as CFMutableData) else { throw LocalFailure(message:"无法创建 PDF 缓冲区") }
 var box = CGRect(x:0,y:0,width:595.28,height:841.89)
 guard let context = CGContext(consumer:consumer,mediaBox:&box,[kCGPDFContextTitle:project.name,kCGPDFContextCreator:"灵语龙"] as CFDictionary) else { throw LocalFailure(message:"无法创建 PDF") }
 let framesetter = CTFramesetterCreateWithAttributedString(body as CFAttributedString)
 var offset = 0; var page = 1
 while offset < body.length {
 context.beginPDFPage(nil)
 let path = CGPath(rect:CGRect(x:46,y:53,width:503.28,height:742.89),transform:nil)
 var frame = CTFramesetterCreateFrame(framesetter,CFRange(location:offset,length:0),path,nil)
 var visible = CTFrameGetVisibleStringRange(frame)
 let end = offset + visible.length
 if let block = blocks.first(where:{$0.location > offset && $0.location < end && NSMaxRange($0) > end}) {
   frame = CTFramesetterCreateFrame(framesetter,CFRange(location:offset,length:block.location-offset),path,nil)
   visible = CTFrameGetVisibleStringRange(frame)
 }
 CTFrameDraw(frame,context)
 guard visible.length > 0 else { context.endPDFPage(); context.closePDF(); throw LocalFailure(message:"PDF 分页失败") }
 let footer = NSAttributedString(string:"灵语龙  /  \(page)",attributes:[.font:NSFont.systemFont(ofSize:9),.foregroundColor:NSColor.gray])
 context.textPosition = CGPoint(x:46,y:27); CTLineDraw(CTLineCreateWithAttributedString(footer),context)
 context.endPDFPage(); offset += visible.length; page += 1
 }
 context.closePDF(); try (data as Data).write(to:url,options:.atomic)
 }
}
