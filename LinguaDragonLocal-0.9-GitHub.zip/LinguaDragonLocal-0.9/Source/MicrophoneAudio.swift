import Foundation
import AVFoundation

// No system-audio or screen capture. Input follows macOS Sound > Input.
@MainActor final class MicrophoneAudio {
 private var engine: AVAudioEngine?
 private var observer: NSObjectProtocol?
 private var generation = UUID()
 var onBuffer: ((AVAudioPCMBuffer)->Void)?
 var onError: ((String)->Void)?
 var onLevel: ((Float)->Void)?
 func start(target:AVAudioFormat) async throws {
 let token = UUID(); generation = token
 let allowed:Bool
 switch AVCaptureDevice.authorizationStatus(for:.audio) {
 case .authorized: allowed = true
 case .notDetermined: allowed = await AVCaptureDevice.requestAccess(for:.audio)
 default: allowed = false
 }
 guard generation == token else { throw CancellationError() }
 guard allowed else { throw LocalFailure(message:"麦克风权限未开启，请在系统设置中允许本应用使用麦克风。") }
 let value = AVAudioEngine()
 let input = value.inputNode
 let format = input.outputFormat(forBus:0)
 guard format.sampleRate > 0, format.channelCount > 0 else { throw LocalFailure(message:"没有可用的麦克风。请连接输入设备，并在系统设置 → 声音 → 输入中选择。") }
 let processing = try MicrophoneConverter(from:format,to:target)
 let bufferHandler = onBuffer, errorHandler = onError, levelHandler = onLevel
 input.installTap(onBus:0,bufferSize:2048,format:format) { buffer,_ in
 do {
 if let output = try processing.convert(buffer) { bufferHandler?(output) }
 if let level = processing.level { levelHandler?(level) }
 } catch { errorHandler?(error.localizedDescription) }
 }
 engine = value
 observer = NotificationCenter.default.addObserver(forName:.AVAudioEngineConfigurationChange,object:value,queue:.main) { [weak self] _ in
 Task { @MainActor in
 guard let self, self.generation == token, self.engine != nil else { return }
 self.onError?("麦克风配置已变化或设备已断开，请确认声音输入设备后重新开始翻译。")
 }
 }
 do { value.prepare(); try value.start() } catch { await stop(); throw LocalFailure(message:"麦克风启动失败：" + error.localizedDescription) }
 }
 func stop() async {
 generation = UUID()
 if let observer { NotificationCenter.default.removeObserver(observer) }; observer = nil
 if let engine { engine.stop(); engine.inputNode.removeTap(onBus:0) }
 engine = nil
 }
}

// One converter per capture; called serially by the input tap, with owned output buffers.
final class MicrophoneConverter {
 private let converter: AVAudioConverter
 private let target: AVAudioFormat
 private var ticks = 0
 private(set) var level:Float?
 init(from:AVAudioFormat,to:AVAudioFormat) throws {
 guard let converter = AVAudioConverter(from:from,to:to) else { throw LocalFailure(message:"无法转换麦克风音频格式。") }
 self.converter = converter; self.target = to
 }
 func convert(_ input:AVAudioPCMBuffer) throws -> AVAudioPCMBuffer? {
 level = nil; ticks += 1
 if ticks % 4 == 0, let channels = input.floatChannelData, input.frameLength > 0 {
 var power:Float = 0
 for channel in 0..<Int(input.format.channelCount) { for index in 0..<Int(input.frameLength) { let sample = channels[channel][index]; power += sample*sample } }
 level = min(1,sqrt(power/Float(input.frameLength*input.format.channelCount))*8)
 }
 let capacity = AVAudioFrameCount(ceil(Double(input.frameLength)*target.sampleRate/input.format.sampleRate)+256)
 guard let output = AVAudioPCMBuffer(pcmFormat:target,frameCapacity:capacity) else { throw LocalFailure(message:"无法分配麦克风音频缓冲区。") }
 var supplied = false; var failure:NSError?
 let result = converter.convert(to:output,error:&failure) { _,flag in
 if supplied { flag.pointee = .noDataNow; return nil }
 supplied = true; flag.pointee = .haveData; return input
 }
 if let failure { throw failure }
 guard result != .error else { throw LocalFailure(message:"麦克风音频转换失败。") }
 return output.frameLength > 0 ? output : nil
 }
}
