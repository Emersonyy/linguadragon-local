import SwiftUI
import AppKit
import Speech
import Translation
import FoundationModels

@MainActor final class Model: ObservableObject {
 static let shared = Model()
 let meeting = MeetingStore()
 let phone = PhoneController()
 @Published var projectName = "未建立工程"
 @Published var projectNotice = "建立工程后自动保存，退出时导出 PDF"
 @Published var projectSheet = false
 @Published var newProjectName = meetingDate(Date(),format:"MM.dd") + " 会议记录"
 @Published var provider = "codex"
 @Published var codexFast = true
 @Published var codexElapsed = ""
 @Published var codexQuestion = "请分析这句话，并给出合适的回复建议。"
 @Published var knowledgeURL:URL?
 @Published var knowledgePurpose = ""
 @Published var knowledgeChecking = false
 var knowledgeCheck:Task<Void,Never>?
 @Published var includeKnowledge = true
 @Published var knowledgeFiles:[String] = []
 @Published var knowledgeNote = ""
 @Published var codexAdvice = ""
 @Published var codexAdviceJapanese = ""
 @Published var captionMode = false
 @Published var captionSize = 26.0
 @Published var ending = false
 var captionText:String {
   if !partialChinese.isEmpty { return String(partialChinese.suffix(320)) }
   if let line = lines.reversed().first(where:{$0.error == nil && !$0.chinese.hasPrefix("正在") && $0.chinese != "翻译暂未完成"}) { return String(line.chinese.suffix(320)) }
   return running ? "正在聆听，等待中文字幕…" : "字幕已开启 · 播放内容后开始翻译"
 }
 func setCaptionMode(_ enabled:Bool) {
   captionMode = enabled
   if enabled { CaptionController.shared.show(model:self); NSApp.windows.first(where:{$0.title == "灵语龙·本地版"})?.orderOut(nil) }
   else { CaptionController.shared.hide(); CaptionController.shared.mainWindow() }
 }
 func persist(_ record:Subtitle) {
   do { try meeting.upsert(record); if meeting.project != nil { projectNotice = "已自动保存 \(meeting.project!.records.count) 段 · 正常退出时生成 PDF" } }
   catch { self.error = "工程保存失败：" + error.localizedDescription }
 }
 func exportMeeting() {
   do { if let url = try meeting.export() { projectNotice = "PDF 已导出：" + url.lastPathComponent } }
   catch { self.error = "PDF 导出失败：" + error.localizedDescription }
 }
 func createProject() {
   guard !running && !working && translationWorker == nil else { error = "请先停止翻译，等待当前翻译完成后建立新工程。"; return }
   do { saveKnowledge(); _ = try meeting.export(); try meeting.create(name:newProjectName); projectName = meeting.project!.name; restoreKnowledge(); lines = []; demo = false; projectSheet = false; projectNotice = "工程已建立 · 每段文字自动保存" }
   catch { self.error = "建立工程失败：" + error.localizedDescription }
 }
 func openProject() {
   guard !running && !working && translationWorker == nil else { return }
   let panel = NSOpenPanel(); panel.canChooseDirectories = true; panel.canChooseFiles = false; panel.message = "选择包含「会议工程.json」的会议文件夹"; panel.directoryURL = meeting.root
   guard panel.runModal() == .OK, let url = panel.url else { return }
   do { saveKnowledge(); _ = try meeting.export(); try meeting.open(url); projectName = meeting.project!.name; restoreKnowledge(); lines = Array(meeting.project!.records.suffix(150)); demo = false; projectNotice = "已打开工程，历史记录完整保留" }
   catch { self.error = "打开工程失败：" + error.localizedDescription }
 }
 func showMeetingFolder() { NSWorkspace.shared.open(meeting.folder ?? meeting.root) }
 func restoreKnowledge() {
 knowledgeURL = meeting.project?.knowledgePath.map { URL(fileURLWithPath:$0) }
 knowledgePurpose = meeting.project?.knowledgePurpose ?? ""
 includeKnowledge = meeting.project?.useKnowledge ?? true
 knowledgeFiles = []; knowledgeNote = ""
 validateKnowledge()
 }
 func saveKnowledge() {
 guard meeting.project != nil else { return }
 meeting.project?.knowledgePath = knowledgeURL?.path
 meeting.project?.knowledgePurpose = knowledgePurpose
 meeting.project?.useKnowledge = includeKnowledge
 do { try meeting.save() } catch { self.error = "参考资料设置保存失败：" + error.localizedDescription }
 }
 func chooseKnowledge() {
   let panel = NSOpenPanel(); panel.canChooseDirectories = true; panel.canChooseFiles = false
   panel.message = "选择准备好的面试或会议资料文件夹：PDF、Word (.docx)、Markdown、TXT。点击询问 Codex 时才发送相关片段。"
   if panel.runModal() == .OK { knowledgeURL = panel.url; includeKnowledge = true; knowledgeFiles = []; knowledgeNote = "资料已绑定；询问时自动检索相关段落。"; saveKnowledge(); validateKnowledge() }
 }
 func validateKnowledge() {
 knowledgeCheck?.cancel(); knowledgeChecking = false
 guard let folder = knowledgeURL else { return }
 knowledgeChecking = true; knowledgeNote = "正在本机读取参考资料，大 PDF 首次处理可能需要一些时间…"
 knowledgeCheck = Task {
 let worker = Task.detached(priority:.utility) { try KnowledgeFolder.read(folder,query:"") }
 do {
 let context = try await withTaskCancellationHandler(operation:{ try await worker.value },onCancel:{ worker.cancel() })
 guard !Task.isCancelled, knowledgeURL == folder else { return }
 knowledgeNote = "资料可用 · " + context.note; knowledgeFiles = context.files
 } catch { guard !Task.isCancelled, knowledgeURL == folder else { return }; knowledgeNote = error.localizedDescription; knowledgeFiles = [] }
 knowledgeChecking = false
 }
 }
 func clearKnowledge() { knowledgeCheck?.cancel(); knowledgeChecking = false; knowledgeURL = nil; knowledgeFiles = []; knowledgeNote = ""; saveKnowledge() }
 // Snapshot only preceding finalized turns; never include later sentences.
 func replyHistory(before id:UUID) -> String {
 let records = meeting.project?.records ?? lines
 let source = records.contains(where:{$0.id == id}) ? records : lines
 guard let index = source.firstIndex(where:{$0.id == id}) else { return "" }
 return source[max(0,index-5)..<index].enumerated().map { offset, line in
 "前文\(offset+1)：\(String(line.source.prefix(1200)))\n中文：\(String(line.chinese.prefix(1200)))"
 }.joined(separator:"\n")
 }
 func askCodex() {
   guard !replyBusy, !knowledgeChecking, let id = selected, let line = lines.first(where:{$0.id == id}) else { return }
   codexElapsed = ""
   let started = Date(); let fast = codexFast
   replyBusy = true; replyError = ""; replies = []; codexAdvice = ""; codexAdviceJapanese = ""
   saveKnowledge()
   let history = replyHistory(before:id)
   let question = "<preceding_conversation>" + history + "</preceding_conversation>\n用途与本人背景：" + knowledgePurpose + "\n本次问题：" + codexQuestion; let folder = includeKnowledge ? knowledgeURL : nil
   replyTask = Task {
     defer { if selected == id { replyBusy = false } }
     do {
       var search = question + " " + line.source + " " + line.chinese
       // English query improves retrieval in English papers without a second cloud call.
       if folder != nil, let english = try? await localTranslate(line.chinese,from:"zh-Hans",to:"en",lane:"knowledge") { search += " " + english }
       let searchText = search
       let context = try await Task.detached(priority:.userInitiated) { try KnowledgeFolder.read(folder,query:searchText) }.value
       try Task.checkCancellation()
       knowledgeFiles = context.files; knowledgeNote = context.note
       let result = try await CodexBridge.query(sentence:line.source,chinese:line.chinese,question:question,knowledge:context,fast:fast)
       guard selected == id && !Task.isCancelled else { return }
       codexElapsed = String(format:"本次耗时 %.1f 秒",Date().timeIntervalSince(started))
       codexAdvice = result.advice_zh; codexAdviceJapanese = furigana(result.advice_ja)
       replies = result.replies.prefix(3).map{Reply(zh:$0.zh,en:"",ja:$0.ja)}
     } catch { if selected == id && !Task.isCancelled { replyError = error.localizedDescription } }
   }
 }
 func shutdown() async -> Bool {
   if ending { return false }; phone.stop(); saveKnowledge(); ending = true
   let remaining = partial.trimmingCharacters(in:.whitespacesAndNewlines)
   running = false; await engine.stop(); resetPreview(); closeReply()
   if !remaining.isEmpty && !demo {
     let record = Subtitle(provisional:true,source:remaining,language:speechLanguage,chinese:"退出时语句尚未确认，未翻译。")
     lines.append(record); persist(record)
   }
   // All finalized source text is already saved; allow a short bounded drain of translations.
   for _ in 0..<30 { if translationWorker == nil { break }; try? await Task.sleep(for:.milliseconds(100)) }
   translationWorker?.cancel()
   do { _ = try meeting.export(); return true }
   catch { self.error = "退出前保存失败：" + error.localizedDescription; ending = false; CaptionController.shared.mainWindow(); return false }
 }

 @Published var lines: [Subtitle] = []
 @Published var language = "ja-JP"
 @Published var audioSource:AudioSource = .system
 @Published var running = false
 @Published var working = false
 @Published var settings = false
 @Published var status = "本地字幕 · Codex 可选回复"
 @Published var error = ""
 @Published var partial = ""
 @Published var partialChinese = ""
 @Published var previewError = ""
 var previewTask: Task<Void,Never>?
 var previewGeneration = UUID()
 var previewTranslate: (String,String) async throws -> String = { text, language in try await localTranslate(text,from:language,to:"zh-Hans",lane:"preview") }
 @Published var level:Float = 0
 @Published var demo = false
 @Published var selected: UUID?
 @Published var replies: [Reply] = []
 @Published var replyBusy = false
 @Published var replyError = ""
 @Published var customReply = ""
 @Published var capability = "正在检查离线组件…"
 @Published var aiStatus = replyAvailability()
 @Published var downloading = false
 @Published var downloadProgress:Double = 0
 @Published var downloadMessage = ""
 @Published var preparation: TranslationSession.Configuration?
 @Published var translationPreparing = false
 @Published var testText = ""
 @Published var copied = ""
 let engine = SpeechEngine()
 var jobs: [UUID] = []
 var translationWorker: Task<Void,Never>?
 var replyTask: Task<Void,Never>?
 var runID = UUID()
 var speechLanguage: String { language.hasPrefix("ja") ? "ja" : "en" }
 var canDemo: Bool { !running && !working && translationWorker == nil }
 init() {
 engine.onText = { [weak self] text,final in guard let self else { return }; if final { self.resetPreview(); self.add(text,language:self.speechLanguage) } else { self.partial = text; self.startPreview() } }
 engine.onError = { [weak self] message in self?.error = message; self?.running = false; self?.status = "采集遇到问题，请查看提示" }
 engine.onLevel = { [weak self] value in self?.level = value }
 }
 func inspect() async {
 aiStatus = replyAvailability()
 var rows:[String] = []
 for (code,name) in [("en-US","英语"),("ja-JP","日语")] {
 do { let module = try await SpeechEngine.module(language:code); let s = await AssetInventory.status(forModules:[module]); rows.append("\(name)识别：\(s == .installed ? "已就绪" : s == .downloading ? "下载中" : "需下载")") } catch { rows.append("\(name)识别：暂不可用") }
 }
 for (from,to,name) in [("en","zh-Hans","英→中"),("ja","zh-Hans","日→中"),("zh-Hans","en","中→英"),("zh-Hans","ja","中→日")] {
 let s = await LanguageAvailability().status(from:Locale.Language(identifier:from),to:Locale.Language(identifier:to))
 rows.append("\(name)：\(s == .installed ? "已就绪" : s == .unsupported ? "不支持" : "需准备")")
 }
 capability = rows.joined(separator:"\n")
 }
 func downloadSpeech() async {
 guard !downloading else { return }; downloading = true; downloadProgress = 0; downloadMessage = "正在准备所选语言的系统识别包…"; error = ""
 do { try await SpeechEngine.prepare(language:language) { [weak self] value in self?.downloadProgress = value }; downloadMessage = "语音识别包已就绪" } catch { downloadMessage = "下载未完成：" + error.localizedDescription }
 downloading = false; await inspect()
 }
 func prepareTranslation(from:String,to:String) {
 guard !translationPreparing else { return }; translationPreparing = true; downloadMessage = "正在准备 \(from) → \(to)，请完成系统下载提示…"
 preparation = .init(source:Locale.Language(identifier:from),target:Locale.Language(identifier:to))
 }
 func prepared(_ session: TranslationSession) async {
 do { try await session.prepareTranslation(); downloadMessage = "离线翻译语言包已就绪" } catch { downloadMessage = "语言包准备未完成：" + error.localizedDescription }
 translationPreparing = false; preparation = nil; await inspect()
 }
 func toggle() async {
 if running { running = false; working = true; await engine.stop(); level = 0; resetPreview(); status = "已停止采集"; working = false; return }
 guard !working && !ending else { return }; working = true; error = ""
 do {
 let ready = await LanguageAvailability().status(from:Locale.Language(identifier:speechLanguage),to:Locale.Language(identifier:"zh-Hans"))
 guard ready == .installed else { settings = true; throw LocalFailure(message:"先在「离线设置」准备所选语言 → 中文的离线翻译包。") }
 if demo { lines = []; demo = false }
 try await engine.start(language:language,source:audioSource); running = true; status = "正在聆听\(audioSource.title) · \(speechLanguage == "ja" ? "日语" : "英语") → 中文"
 } catch { self.error = error.localizedDescription }
 working = false
 }
 func resetPreview() {
 previewGeneration = UUID(); previewTask?.cancel(); previewTask = nil
 partial = ""; partialChinese = ""; previewError = ""
 }
 func startPreview() {
 guard previewTask == nil, !ending else { return }
 let generation = previewGeneration; let sourceLanguage = speechLanguage
 previewTask = Task {
 var translated = ""
 // Throttle, not debounce: continuous speech must not postpone translation forever.
 while !Task.isCancelled && previewGeneration == generation {
 do { try await Task.sleep(for:.milliseconds(900)) } catch { break }
 let snapshot = partial.trimmingCharacters(in:.whitespacesAndNewlines)
 guard snapshot.count >= 4, snapshot != translated else { continue }
 translated = snapshot
 do {
 let result = try await previewTranslate(snapshot,sourceLanguage)
 guard !Task.isCancelled, previewGeneration == generation else { break }
 partialChinese = result; previewError = ""
 } catch {
 if !Task.isCancelled && previewGeneration == generation { previewError = "预览暂不可用，等待语句确认后翻译" }
 }
 }
 }
 }
 func add(_ text: String, language:String) {
 let clean = text.trimmingCharacters(in:.whitespacesAndNewlines); guard !clean.isEmpty else { return }
 guard jobs.count < 15 else { error = "翻译处理积压，已跳过新片段。请暂停或关闭其他大型应用。"; return }
 let line = Subtitle(source:clean,language:language); lines.append(line); jobs.append(line.id)
 persist(line)
 if lines.count > 150 { lines.removeFirst() }
 if translationWorker == nil { translationWorker = Task { await translateJobs() } }
 }
 func translateJobs() async {
 while !jobs.isEmpty && !Task.isCancelled {
 let id = jobs.removeFirst(); guard let line = lines.first(where:{$0.id == id}) else { continue }
 do { let result = try await localTranslate(line.source,from:line.language,to:"zh-Hans"); if let i = lines.firstIndex(where:{$0.id == id}) { lines[i].chinese = result; lines[i].error = nil; persist(lines[i]) } }
 catch { if let i = lines.firstIndex(where:{$0.id == id}) { lines[i].chinese = "翻译暂未完成"; lines[i].error = error.localizedDescription; persist(lines[i]) } }
 }
 translationWorker = nil
 }
 func retry(_ id:UUID) { guard !jobs.contains(id) else { return }; jobs.append(id); if translationWorker == nil { translationWorker = Task { await translateJobs() } } }
 func translateTyped() { guard !running, !working, translationWorker == nil else { return }; if demo { demo = false; lines = [] }; add(testText,language:speechLanguage); testText = "" }
 func openReply(_ id:UUID) {
 replyTask?.cancel(); selected = id; replies = []; replyError = ""; customReply = ""; copied = ""
 codexAdvice = ""; codexAdviceJapanese = ""; knowledgeFiles = []; knowledgeNote = ""
 if provider == "local" || demo { replyTask = Task { await generateReply(id) } }
 }
 func generateReply(_ id:UUID) async {
 guard let line = lines.first(where:{$0.id == id}) else { return }; replyBusy = true
 defer { if selected == id { replyBusy = false } }
 do {
 if demo { replies = [Reply(zh:"我需要先确认一下，稍后回复你。",en:"Let me check first and get back to you.",ja:"先に確認して、後ほどお返事します。"),Reply(zh:"可以再说明一下具体要求吗？",en:"Could you clarify the specific requirements?",ja:"具体的な要件をもう少し説明していただけますか。")]; return }
 let drafts = try await makeLocalDrafts(question:replyHistory(before:id) + "\n当前句：" + line.source + "\n中文：" + line.chinese)
 for draft in drafts { try Task.checkCancellation(); let reply = try await translateReply(draft); if selected == id && !Task.isCancelled { replies.append(reply) } }
 } catch { if selected == id && !Task.isCancelled { replyError = error.localizedDescription } }
 }
 func translateReply(_ zh:String) async throws -> Reply {
 try Task.checkCancellation()
 let ja = try await localTranslate(zh,from:"zh-Hans",to:"ja"); return Reply(zh:zh,en:"",ja:ja)
 }
 func custom() {
 guard !replyBusy, !knowledgeChecking, let id = selected else { return }
 let value = customReply.trimmingCharacters(in:.whitespacesAndNewlines); guard !value.isEmpty else { return }
 replyBusy = true; replyError = ""
 replyTask = Task {
 defer { if selected == id { replyBusy = false } }
 do { let reply = try await translateReply(value); if selected == id && !Task.isCancelled { replies.append(reply) } }
 catch { if selected == id && !Task.isCancelled { replyError = error.localizedDescription } }
 }
 }
 func closeReply() { replyTask?.cancel(); selected = nil; replyBusy = false }
 func showDemo() { guard canDemo else { return }; if meeting.project != nil { error = "会议工程打开期间不进入演示，避免混入示例。"; return }; demo = true; lines = [Subtitle(source:"Could you send me the updated proposal by tomorrow afternoon?",language:"en",chinese:"你能在明天下午之前把更新后的方案发给我吗？"),Subtitle(source:"次の会議は木曜日の午前十時からです。",language:"ja",chinese:"下次会议从周四上午十点开始。")]; status = "演示模式 · 固定示例，不是实际识别" }
 func copy(_ value:String,label:String) { NSPasteboard.general.clearContents(); NSPasteboard.general.setString(value,forType:.string); copied = "已复制" + label }
}

struct Content: View {
 @StateObject var m = Model.shared
 @ObservedObject var phone = Model.shared.phone
 @State var top = true
 let blue = Color(red:0.20,green:0.46,blue:0.68)
 var body: some View {
 HStack(spacing:0) { sidebar; main }
 .frame(minWidth:900,minHeight:710).tint(blue).preferredColorScheme(.light)
 .task { await m.inspect() }
 .sheet(isPresented:$phone.sheet) { PhonePanel(phone:phone,model:m) }
 .sheet(isPresented:$m.settings) { settingsView }
 .sheet(isPresented:$m.projectSheet) { projectView }
 .sheet(isPresented:Binding(get:{m.selected != nil},set:{if !$0 { m.closeReply() }})) { repliesView }
 }
 var sidebar: some View { VStack(alignment:.leading,spacing:16) {
 if let url = Bundle.main.url(forResource:"avatar",withExtension:"png"), let image = NSImage(contentsOf:url) { Image(nsImage:image).resizable().scaledToFit().frame(width:155,height:155).clipShape(RoundedRectangle(cornerRadius:26)) }
 Text("灵语龙").font(.system(size:30,weight:.bold,design:.rounded)); Text("会议版 · 0.9").font(.caption).tracking(2).foregroundStyle(blue)
 Text("听懂对话\n留住会议记录").font(.title3).foregroundStyle(.secondary).lineSpacing(5)
 Divider()
 Picker("声音来源",selection:$m.audioSource) { ForEach(AudioSource.allCases) { Text($0.title).tag($0) } }.disabled(m.running || m.working || m.downloading)
 Text(m.audioSource.hint).font(.caption2).foregroundStyle(.secondary)
 Picker("对方语言",selection:$m.language) { Text("日语").tag("ja-JP"); Text("英语").tag("en-US") }.disabled(m.running || m.working || m.downloading)
 Button { Task { await m.toggle() } } label: { Label(m.running ? "停止翻译" : "开始翻译",systemImage:m.running ? "stop.fill" : "waveform").frame(maxWidth:.infinity).padding(8) }.buttonStyle(.borderedProminent).disabled(m.working || m.downloading)
 if m.working { ProgressView().controlSize(.small) }
 Toggle("窗口置顶",isOn:$top).onChange(of:top) { _,v in NSApp.windows.filter{$0.title == "灵语龙·本地版"}.forEach{$0.level = v ? .floating : .normal} }
 Button("手机显示 · 扫码") { phone.sheet = true; phone.start(model:m) }
 Button("桌面字幕模式") { m.setCaptionMode(!m.captionMode) }
 Text("字幕条可拖动；双击返回主窗口").font(.caption2).foregroundStyle(.secondary)
 Spacer()
 Button("离线设置 / 下载语言包") { m.settings = true }.disabled(m.running || m.working)
 Button("查看演示") { m.showDemo() }.disabled(!m.canDemo)
 Text("字幕在本机处理。\nCodex 回复需联网并使用账户额度。\n无需填写 API Key。").font(.caption2).foregroundStyle(.secondary).lineSpacing(4)
 }.padding(24).frame(width:220).background(Color(red:0.91,green:0.95,blue:0.99)) }
 var main: some View { VStack(alignment:.leading,spacing:16) {
 HStack { VStack(alignment:.leading,spacing:6) { Text("实时字幕").font(.title.bold()); Text(m.status).font(.caption).foregroundStyle(.secondary) }; Spacer(); Label("本地字幕",systemImage:"lock.shield").font(.caption).foregroundStyle(blue) }
 VStack(alignment:.leading,spacing:6) {
 HStack { Label(m.projectName,systemImage:"folder").font(.headline); Spacer(); Button("新建工程") { m.projectSheet = true }; Button("打开") { m.openProject() }; Button("导出 PDF") { m.exportMeeting() }.disabled(m.meeting.project == nil) }
 HStack { Text(m.projectNotice).font(.caption).foregroundStyle(.secondary); Spacer(); Button("查看文件夹") { m.showMeetingFolder() }.disabled(m.meeting.project == nil) }
 HStack { Label(m.knowledgeURL?.lastPathComponent ?? "未选择参考资料",systemImage:"books.vertical").font(.caption); Spacer(); Button("选择参考资料") { m.chooseKnowledge() }.disabled(m.replyBusy); if m.knowledgeURL != nil { Button("解除关联") { m.clearKnowledge() }.disabled(m.replyBusy) } }
 if !m.knowledgeNote.isEmpty { Text(m.knowledgeNote).font(.caption2).foregroundStyle(.secondary).lineLimit(4).textSelection(.enabled) }
 TextField("用途与本人背景（如：博士面试，我负责论文中的图像分割实验）",text:$m.knowledgePurpose).textFieldStyle(.roundedBorder).onChange(of:m.knowledgePurpose) { _,_ in m.saveKnowledge() }.disabled(m.replyBusy)
 Text(m.meeting.project == nil ? "建立工程后可保存资料关联；询问 Codex 时才发送相关片段。" : "资料随工程关联；询问 Codex 时引用。PDF / DOCX / Markdown / TXT").font(.caption2).foregroundStyle(.secondary)

 }.padding(12).background(.blue.opacity(0.04)).clipShape(RoundedRectangle(cornerRadius:12))
 if !m.error.isEmpty { HStack(alignment:.top) { Text(m.error).font(.callout).foregroundStyle(.red).textSelection(.enabled); Spacer(); Button("关闭") { m.error = "" } }.padding(12).background(.red.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius:12)) }
 if m.running { HStack { Image(systemName:"waveform"); ProgressView(value:Double(m.level)).frame(width:100); Text(m.level > 0.01 ? "检测到\(m.audioSource.title)声音" : "等待\(m.audioSource.title)输入").font(.caption).foregroundStyle(.secondary) } }
 ScrollViewReader { proxy in ScrollView { LazyVStack(alignment:.leading,spacing:14) {
 if m.lines.isEmpty && m.partial.isEmpty { VStack(spacing:16) { Image(systemName:"waveform.and.magnifyingglass").font(.system(size:44)).foregroundStyle(blue); Text(m.audioSource == .system ? "先准备离线语言包，再播放会议或视频" : "先准备离线语言包，再对着麦克风说话").font(.title3); Text("选择对方语言，点击开始翻译。\n回复建议只在你点击「帮我回复」时出现。").foregroundStyle(.secondary).multilineTextAlignment(.center); Button("检查离线设置") { m.settings = true } }.frame(maxWidth:.infinity).padding(.top,70) }
 ForEach(m.lines) { line in VStack(alignment:.leading,spacing:10) { Text(line.source).font(.callout).foregroundStyle(.secondary).textSelection(.enabled); Text(line.chinese).font(.system(size:21,weight:.medium)).textSelection(.enabled)
 if let error = line.error { Text(error).font(.caption).foregroundStyle(.red); Button("重试翻译") { m.retry(line.id) } }
 HStack { if line.question { Label("可能是问题",systemImage:"questionmark.bubble").font(.caption).foregroundStyle(blue) }; Spacer(); Button(line.question ? "帮我回复" : "回复此句") { m.openReply(line.id) }.buttonStyle(.bordered) }
 }.padding(18).frame(maxWidth:.infinity,alignment:.leading).background(.white).clipShape(RoundedRectangle(cornerRadius:16)).id(line.id) }
 if !m.partial.isEmpty { VStack(alignment:.leading,spacing:6) { Text("边说边译 · 预览会随识别修正").font(.caption).foregroundStyle(blue); Text(m.partial).foregroundStyle(.secondary); if !m.partialChinese.isEmpty { Text(m.partialChinese).font(.title3).textSelection(.enabled) }; if !m.previewError.isEmpty { Text(m.previewError).font(.caption).foregroundStyle(.secondary) } }.padding(14).id("partial") }
 }.padding(2) }.onChange(of:m.lines.count) { _,_ in if let last = m.lines.last { withAnimation { proxy.scrollTo(last.id,anchor:.bottom) } } } }
 Divider()
 HStack { TextField("也可输入一句日语/英语，测试本地翻译",text:$m.testText).textFieldStyle(.roundedBorder).onSubmit { m.translateTyped() }; Button("翻译") { m.translateTyped() }.disabled(m.running || m.working || m.translationWorker != nil || m.testText.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty) }
 Text("M1 / 8 GB：建议关闭大型应用。先显示中文预览，语句确认后保存；识别、翻译和假名可能有误。").font(.caption).foregroundStyle(.secondary)
 }.padding(26).frame(minWidth:570).background(Color(red:0.97,green:0.98,blue:1)) }
 var settingsView: some View { VStack(alignment:.leading,spacing:16) {
 HStack { Text("离线设置").font(.title2.bold()); Spacer(); Button("完成") { m.settings = false }.disabled(m.downloading || m.translationPreparing) }
 Text("首次使用需下载 Apple 的语言包，之后识别与翻译在本机完成。不需要 OpenAI 账户或充值。").foregroundStyle(.secondary)
 Text(m.capability).font(.system(.callout,design:.monospaced)).lineSpacing(4).textSelection(.enabled)
 Divider()
 HStack { Picker("语音包",selection:$m.language) { Text("日语").tag("ja-JP"); Text("英语").tag("en-US") }.frame(width:180).disabled(m.downloading); Button("准备语音识别包") { Task { await m.downloadSpeech() } }.disabled(m.downloading || m.translationPreparing) }
 if m.downloading { ProgressView(value:m.downloadProgress); Text("下载中，请保持联网；大小和速度由系统决定。").font(.caption) }
 Text("翻译语言包（字幕与回复都需要）").font(.headline)
 HStack { Button("英 → 中") { m.prepareTranslation(from:"en",to:"zh-Hans") }; Button("日 → 中") { m.prepareTranslation(from:"ja",to:"zh-Hans") }; Button("中 → 英") { m.prepareTranslation(from:"zh-Hans",to:"en") }; Button("中 → 日") { m.prepareTranslation(from:"zh-Hans",to:"ja") } }.disabled(m.translationPreparing || m.downloading)
 if m.translationPreparing { ProgressView().controlSize(.small) }
 if !m.downloadMessage.isEmpty { Text(m.downloadMessage).font(.callout).textSelection(.enabled) }
 Divider()
 Text(m.aiStatus).font(.callout).foregroundStyle(.secondary)
 Text("自动回复依赖系统 Apple Intelligence 的可用性。未就绪时可以自己写中文，再翻成英语和日语。这里不调用 ChatGPT 或云端模型。").font(.caption).foregroundStyle(.secondary)
 Button("刷新组件状态") { Task { await m.inspect() } }.disabled(m.downloading || m.translationPreparing)
 }.padding(28).frame(width:560)
 .translationTask(m.preparation) { session in await m.prepared(session) }
 }
 var projectView:some View { VStack(alignment:.leading,spacing:18) {
 Text("新建会议工程").font(.title2.bold())
 TextField("例如：10.23 产品讨论会议",text:$m.newProjectName).textFieldStyle(.roundedBorder)
 Text("保存位置：桌面 / 会议记录 / 工程名\n原文和译文逐段自动保存；正常退出时自动生成 PDF。").foregroundStyle(.secondary)
 HStack { Button("取消") { m.projectSheet = false }; Spacer(); Button("建立工程") { m.createProject() }.buttonStyle(.borderedProminent).disabled(m.running || m.working || m.translationWorker != nil) }
 if m.running || m.translationWorker != nil { Text("请先停止翻译并等待当前翻译完成。").foregroundStyle(.orange) }
 }.padding(28).frame(width:480) }
 var repliesView: some View { VStack(alignment:.leading,spacing:12) {
 HStack { Text("询问与回复").font(.title2.bold()); Spacer(); Button("关闭") { m.closeReply() } }
 if let line = m.lines.first(where:{$0.id == m.selected}) { Text(line.source).font(.caption).foregroundStyle(.secondary).lineLimit(3); Text(line.chinese).font(.headline).lineLimit(3) }
 Picker("回复方式",selection:$m.provider) { Text("Codex · ChatGPT 账户").tag("codex"); Text("本机模型").tag("local") }.pickerStyle(.segmented).disabled(m.replyBusy)
 if m.provider == "codex" {
 Picker("响应速度",selection:$m.codexFast) { Text("快速回复").tag(true); Text("详细分析").tag(false) }.pickerStyle(.segmented).disabled(m.replyBusy)
 TextField("针对这句话，你想问 Codex 什么？",text:$m.codexQuestion).textFieldStyle(.roundedBorder)
 HStack { Button("选择知识文件夹") { m.chooseKnowledge() }.disabled(m.replyBusy); Text(m.knowledgeURL?.lastPathComponent ?? "未选择").font(.caption).lineLimit(1); Spacer(); Toggle("附带文档",isOn:$m.includeKnowledge).onChange(of:m.includeKnowledge) { _,_ in m.saveKnowledge() }.disabled(m.replyBusy || m.knowledgeURL == nil) }
 Text("点击后将当前句子、你的问题及所选文档片段发送给 Codex；使用账户额度，不自动发送回复。").font(.caption2).foregroundStyle(.secondary)
 Button("询问 Codex") { m.askCodex() }.buttonStyle(.borderedProminent).disabled(m.replyBusy || m.demo || m.knowledgeChecking)
 } else { Button("生成本地回复") { if let id = m.selected { m.replyTask = Task { await m.generateReply(id) } } }.disabled(m.replyBusy) }
 if m.replyBusy { ProgressView(m.provider == "codex" ? "Codex 正在思考…" : "本机模型正在生成…").controlSize(.small) }
 if !m.replyError.isEmpty { Text(m.replyError).font(.callout).foregroundStyle(.orange).textSelection(.enabled) }
 ScrollView { LazyVStack(alignment:.leading,spacing:14) {
 if !m.codexElapsed.isEmpty { Text(m.codexElapsed).font(.caption).foregroundStyle(.secondary) }
 if !m.codexAdvice.isEmpty { VStack(alignment:.leading,spacing:8) { Text("Codex 的意见").font(.headline); Text(m.codexAdvice).textSelection(.enabled); Text(m.codexAdviceJapanese).textSelection(.enabled).foregroundStyle(.secondary) }.padding(14).background(.blue.opacity(0.04)).clipShape(RoundedRectangle(cornerRadius:12)) }
 ForEach(m.replies) { r in VStack(alignment:.leading,spacing:10) { replyRow("中文",r.zh,copy:r.zh); replyRow("日本語 · 假名注解",r.kana,copy:r.ja); HStack { Spacer(); Button("复制带假名版本") { m.copy(r.kana,label:"带假名日文") } } }.padding(16).frame(maxWidth:.infinity,alignment:.leading).background(Color.blue.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius:14)) }
 if !m.knowledgeNote.isEmpty { Text(m.knowledgeNote).font(.caption2).foregroundStyle(.secondary); ForEach(m.knowledgeFiles,id:\.self) { Text($0).font(.caption2).textSelection(.enabled) } }
 } }
 Divider(); Text("自己写中文回复").font(.headline)
 HStack { TextField("例如：我需要先确认一下时间。",text:$m.customReply).textFieldStyle(.roundedBorder); Button("翻成日语") { m.custom() }.disabled(m.replyBusy || m.customReply.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty) }
 HStack { Text("假名在本机生成，姓名等读音请核对。").font(.caption2).foregroundStyle(.secondary); Spacer(); Text(m.copied).font(.caption).foregroundStyle(.green) }
 }.padding(24).frame(width:690,height:740) }
 func replyRow(_ label:String,_ display:String,copy:String) -> some View { VStack(alignment:.leading,spacing:5) { HStack { Text(label).font(.caption).foregroundStyle(.secondary); Spacer(); Button("复制") { m.copy(copy,label:label) } }; Text(display).textSelection(.enabled) } }
}
@MainActor final class Delegate: NSObject, NSApplicationDelegate {
 var statusItem:NSStatusItem?
 var quitting = false
 func applicationDidFinishLaunching(_ notification:Notification) {
   NSApp.setActivationPolicy(.regular); NSApp.activate(ignoringOtherApps:true)
   DispatchQueue.main.async { NSApp.windows.first?.level = .floating }
   statusItem = NSStatusBar.system.statusItem(withLength:NSStatusItem.variableLength); statusItem?.button?.title = "灵语"
   let menu = NSMenu()
   for (title,selector) in [("显示主窗口",#selector(showMain)),("切换桌面字幕",#selector(toggleCaptions)),("导出会议 PDF",#selector(exportPDF)),("退出并保存",#selector(quit))] { let item = NSMenuItem(title:title,action:selector,keyEquivalent:""); item.target = self; menu.addItem(item) }
   statusItem?.menu = menu
 }
 @objc func showMain() { CaptionController.shared.mainWindow() }
 @objc func toggleCaptions() { Model.shared.setCaptionMode(!Model.shared.captionMode) }
 @objc func exportPDF() { Model.shared.exportMeeting() }
 @objc func quit() { NSApp.terminate(nil) }
 func applicationShouldTerminateAfterLastWindowClosed(_ sender:NSApplication) -> Bool { !Model.shared.captionMode }
 func applicationShouldTerminate(_ sender:NSApplication) -> NSApplication.TerminateReply {
   if quitting { return .terminateLater }; quitting = true
   Task { let saved = await Model.shared.shutdown(); if !saved { quitting = false }; sender.reply(toApplicationShouldTerminate:saved) }
   return .terminateLater
 }
}
@main struct DragonLocal: App { @NSApplicationDelegateAdaptor(Delegate.self) var delegate; var body:some Scene { Window("灵语龙·本地版",id:"main") { Content() }.windowStyle(.hiddenTitleBar) } }
