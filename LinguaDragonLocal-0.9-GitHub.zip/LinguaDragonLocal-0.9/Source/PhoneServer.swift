import Foundation
import Network
import SwiftUI
import CoreGraphics
@_silgen_name("dragon_phone_qr") private func dragonPhoneQR(_ text:UnsafePointer<CChar>,_ pixels:UnsafeMutablePointer<UInt8>)->Int32
import Darwin

// Listener lifecycle/handler are MainActor-owned; connection state is confined to queue.
final class PhoneServer: @unchecked Sendable {
 private var listener:NWListener?
 private let queue = DispatchQueue(label:"dragon.phone")
 private var connections:[UUID:NWConnection] = [:]
 @MainActor var handler: (@MainActor (String,Data) -> (Int,Data))?
 @MainActor func start(token:String,ready:@escaping @MainActor (UInt16?,String?)->Void) throws {
 let listener = try NWListener(using:.tcp,on:.any); self.listener = listener
 listener.stateUpdateHandler = { state in
 switch state {
 case .ready: Task { @MainActor in ready(listener.port?.rawValue,nil) }
 case .failed(let e): Task { @MainActor in ready(nil,e.localizedDescription) }
 default: break
 }
 }
 listener.newConnectionHandler = { [weak self] connection in
 guard let self else { connection.cancel(); return }
 guard self.connections.count < 32 else { connection.cancel(); return }
 let id = UUID(); self.connections[id] = connection; connection.start(queue:self.queue)
 self.queue.asyncAfter(deadline:.now()+8) { if self.connections.removeValue(forKey:id) != nil { connection.cancel() } }
 self.receive(connection,id:id,token:token,buffer:Data())
 }
 listener.start(queue:queue)
 }
 @MainActor func stop() {
 listener?.cancel(); listener = nil
 queue.async { self.connections.values.forEach{$0.cancel()}; self.connections.removeAll() }
 }
 private func receive(_ connection:NWConnection,id:UUID,token:String,buffer:Data) {
 connection.receive(minimumIncompleteLength:1,maximumLength:16384) { [weak self] data,_,complete,error in
 guard let self else { return }
 var accumulated = buffer; accumulated.append(data ?? Data())
 if accumulated.count > 24000 { self.send(connection,id:id,status:413,data:Data()); return }
 guard let end = accumulated.range(of:Data("\r\n\r\n".utf8)) else {
 if !complete && error == nil { self.receive(connection,id:id,token:token,buffer:accumulated) }; return
 }
 let header = String(decoding:accumulated[..<end.lowerBound],as:UTF8.self).components(separatedBy:"\r\n")
 let request = (header.first ?? "").split(separator:" "); guard request.count == 3 else { self.send(connection,id:id,status:400,data:Data()); return }
 var headers:[String:String] = [:]
 for line in header.dropFirst() { let pair = line.split(separator:":",maxSplits:1); if pair.count == 2 { headers[String(pair[0]).lowercased()] = pair[1].trimmingCharacters(in:.whitespaces) } }
 let length = Int(headers["content-length"] ?? "0") ?? -1
 guard length >= 0 && length <= 16000 && headers["transfer-encoding"] == nil else { self.send(connection,id:id,status:400,data:Data()); return }
 let body = accumulated[end.upperBound...]
 if body.count < length { if !complete && error == nil { self.receive(connection,id:id,token:token,buffer:accumulated) }; return }
 let path = String(request[1]); let method = String(request[0])
 if path == "/" && method == "GET" { self.send(connection,id:id,status:200,data:Data(phoneHTML.utf8),html:true); return }
 guard headers["authorization"] == "Bearer " + token else { self.send(connection,id:id,status:401,data:Data("{\"error\":\"配对已失效，请重新扫码\"}".utf8)); return }
 if let origin = headers["origin"], origin != "http://" + (headers["host"] ?? "") { self.send(connection,id:id,status:403,data:Data()); return }
 guard (method == "GET" && path == "/state") || (method == "POST" && path == "/action") else { self.send(connection,id:id,status:404,data:Data()); return }
 let payload = Data(body.prefix(length))
 Task { @MainActor in
 let result = self.handler?(path,payload) ?? (503,Data())
 self.queue.async { self.send(connection,id:id,status:result.0,data:result.1) }
 }
 }
 }
 private func send(_ connection:NWConnection,id:UUID,status:Int,data:Data,html:Bool = false) {
 let headers = "HTTP/1.1 \(status) Result\r\nContent-Type: \(html ? "text/html; charset=utf-8" : "application/json; charset=utf-8")\r\nContent-Length: \(data.count)\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nX-Content-Type-Options: nosniff\r\nContent-Security-Policy: default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'\r\nConnection: close\r\n\r\n"
 connection.send(content:Data(headers.utf8)+data,completion:.contentProcessed { _ in connection.cancel(); self.connections.removeValue(forKey:id) })
 }
}
func phoneAddresses() -> [String] {
 var first:UnsafeMutablePointer<ifaddrs>?; guard getifaddrs(&first) == 0 else { return [] }; defer { freeifaddrs(first) }
 var result:[String] = []; var cursor = first
 while let node = cursor { defer { cursor = node.pointee.ifa_next }
 guard let address = node.pointee.ifa_addr, address.pointee.sa_family == UInt8(AF_INET), (node.pointee.ifa_flags & UInt32(IFF_LOOPBACK)) == 0, (node.pointee.ifa_flags & UInt32(IFF_UP)) != 0 else { continue }
 let name = String(cString:node.pointee.ifa_name); guard name.hasPrefix("en") || name.hasPrefix("bridge") else { continue }
 var host = [CChar](repeating:0,count:Int(NI_MAXHOST))
 if getnameinfo(address,socklen_t(address.pointee.sa_len),&host,socklen_t(host.count),nil,0,NI_NUMERICHOST) == 0 { result.append(String(cString:host)) }
 }
 return Array(Set(result)).sorted()
}
@MainActor final class PhoneController:ObservableObject {
 @Published var active = false
 @Published var urls:[String] = []
 @Published var error = ""
 @Published var chosen = ""
 @Published var sheet = false
 var translate: (String) async throws -> String = { try await localTranslate($0,from:"zh-Hans",to:"ja",lane:"phone") }
 var advise: (String,String,String,KnowledgeExcerpt) async throws -> CodexAnswer = { try await CodexBridge.query(sentence:$0,chinese:$1,question:$2,knowledge:$3,fast:true) }
 private var server:PhoneServer?
 private var task:Task<Void,Never>?
 private var generation = UUID()
 private var busy = false
 private var result:[String:Any] = [:]
 func start(model:Model) {
 guard server == nil else { return }; error = ""; result = [:]
 let token = UUID().uuidString + UUID().uuidString; let session = UUID(); generation = session
 let value = PhoneServer(); server = value
 value.handler = { [weak self,weak model] path,data in
 guard let self, let model, self.generation == session else { return (503,Data()) }
 if path == "/state" {
 let lines = model.lines.suffix(60).map { ["id":$0.id.uuidString,"source":$0.source,"chinese":$0.chinese] }
 let state:[String:Any] = ["project":model.projectName,"status":model.status,"running":model.running,"partial":model.partial,"preview":model.partialChinese,"lines":lines,"busy":self.busy,"result":self.result,"materials":model.knowledgeURL?.lastPathComponent ?? "未关联资料","materialStatus":model.knowledgeNote]
 return (200, self.json(state))
 }
 guard !self.busy && !model.knowledgeChecking else { return (409,self.json(["error":"上一条回复正在处理，请稍候"])) }
 guard let input = try? JSONSerialization.jsonObject(with:data) as? [String:Any], let action = input["action"] as? String else { return (400,self.json(["error":"无效请求"])) }
 let text = String((input["text"] as? String ?? "").prefix(2000))
 let use = input["materials"] as? Bool ?? true
 let line = model.lines.first { $0.id.uuidString == input["id"] as? String }
 guard (action == "translate" && !text.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty) || (action == "ask" && line != nil && !model.demo) else { return (400,self.json(["error":"请选择真实字幕，或输入中文"])) }
 let folder = use ? model.knowledgeURL : nil; let purpose = model.knowledgePurpose
 let history = line.map { model.replyHistory(before:$0.id) } ?? ""
 self.busy = true; self.result = ["message":"Mac 正在后台处理…"]
 self.task = Task { [weak self] in
 guard let self else { return }
 defer { if self.generation == session { self.busy = false } }
 do {
 let output:[String:Any]
 if action == "translate" {
 let ja = try await self.translate(text)
 output = ["replies":[["zh":text,"ja":ja,"kana":furigana(ja)]]]
 } else {
 let line = line!
 let query = history + " " + line.source + " " + line.chinese + " " + text
 let context = try await Task.detached { try KnowledgeFolder.read(folder,query:query) }.value
 try Task.checkCancellation()
 let answer = try await self.advise(line.source,line.chinese,"<preceding_conversation>\(history)</preceding_conversation>\n本人背景：\(purpose)\n" + (text.isEmpty ? "请提供可以直接说出口的简短回复。" : text),context)
 output = ["advice":answer.advice_zh,"adviceJa":furigana(answer.advice_ja),"files":context.files,"note":context.note,"replies":answer.replies.map{["zh":$0.zh,"ja":$0.ja,"kana":furigana($0.ja)]}]
 }
 if self.generation == session && !Task.isCancelled { self.result = output }
 } catch { if self.generation == session && !Task.isCancelled { self.result = ["error":error.localizedDescription] } }
 }
 return (202,self.json(["ok":true]))
 }
 do { try value.start(token:token) { [weak self] port,failure in
 guard let self, self.generation == session else { return }
 if let failure { self.stop(); self.error = failure; return }
 if let port { self.urls = phoneAddresses().map{"http://\($0):\(port)/#\(token)"}; self.chosen = self.urls.first ?? ""; self.active = true; if self.urls.isEmpty { self.error = "未找到局域网地址，请连接 Wi-Fi 后停止并重新开启。" } }
 } } catch { stop(); self.error = error.localizedDescription }
 }
 func stop() { generation = UUID(); task?.cancel(); task = nil; server?.stop(); server = nil; active = false; busy = false; urls = []; chosen = ""; result = [:] }
 private func json(_ value:[String:Any])->Data { (try? JSONSerialization.data(withJSONObject:value)) ?? Data("{}".utf8) }
 var qr:NSImage? {
 guard !chosen.isEmpty else { return nil }
 var pixels = [UInt8](repeating:255,count:40000)
 let side = chosen.withCString { text in pixels.withUnsafeMutableBufferPointer { Int(dragonPhoneQR(text,$0.baseAddress!)) } }
 guard side > 0, let provider = CGDataProvider(data:Data(pixels.prefix(side*side)) as CFData), let cg = CGImage(width:side,height:side,bitsPerComponent:8,bitsPerPixel:8,bytesPerRow:side,space:CGColorSpaceCreateDeviceGray(),bitmapInfo:CGBitmapInfo(rawValue:0),provider:provider,decode:nil,shouldInterpolate:false,intent:.defaultIntent) else { return nil }
 return NSImage(cgImage:cg,size:NSSize(width:240,height:240))
 }
}
struct PhonePanel:View {
 @ObservedObject var phone:PhoneController
 let model:Model
 var body:some View { VStack(spacing:14) {
 Text("手机显示与回复").font(.title2.bold())
 Text("手机和 Mac 连接同一 Wi-Fi，用手机浏览器扫描二维码。").font(.callout)
 if let qr = phone.qr { Image(nsImage:qr).interpolation(.none).resizable().frame(width:240,height:240) }
 if phone.urls.count > 1 { Picker("网络地址",selection:$phone.chosen) { ForEach(phone.urls,id:\.self) { Text(URLComponents(string:$0)?.host ?? $0).tag($0) } } }
 if !phone.chosen.isEmpty { Button("复制连接地址") { NSPasteboard.general.clearContents(); NSPasteboard.general.setString(phone.chosen,forType:.string) } }
 if !phone.error.isEmpty { Text(phone.error).foregroundStyle(.red) }
 Text("仅在可信局域网使用：连接为 HTTP，未加密；二维码是访问凭证，请勿转发。关闭连接后旧码失效。Mac 必须保持运行。手机请求不会弹出电脑回复窗口，但共享整屏时仍可能看到系统提示。").font(.caption).foregroundStyle(.secondary)
 HStack {
 Button(phone.active ? "停止手机连接" : "开启手机连接") { if phone.active { phone.stop() } else { phone.start(model:model) } }
 Button("完成") { phone.sheet = false }
 Button("收起电脑窗口") { phone.sheet = false; DispatchQueue.main.asyncAfter(deadline:.now()+0.3) { NSApp.windows.filter{$0.title == "灵语龙·本地版"}.forEach{$0.orderOut(nil)}; CaptionController.shared.hide() } }
 }
 }.padding(24).frame(width:470) }
}
