import SwiftUI
import AppKit

@MainActor final class CaptionController {
 static let shared = CaptionController()
 private var panel:NSPanel?
 func show(model:Model) {
 if panel == nil {
 let screen = NSScreen.main?.visibleFrame ?? CGRect(x:0,y:0,width:1200,height:800)
 let width = min(850,screen.width-80)
 let p = NSPanel(contentRect:CGRect(x:screen.midX-width/2,y:screen.minY+65,width:width,height:140),styleMask:[.borderless,.nonactivatingPanel,.resizable],backing:.buffered,defer:false)
 p.title = "灵语龙桌面字幕"; p.isFloatingPanel = true; p.level = .floating; p.hidesOnDeactivate = false; p.isMovableByWindowBackground = true; p.isOpaque = false; p.backgroundColor = .clear; p.hasShadow = true; p.isReleasedWhenClosed = false; p.collectionBehavior = [.canJoinAllSpaces,.fullScreenAuxiliary]; p.minSize = NSSize(width:360,height:90)
 p.contentView = NSHostingView(rootView:CaptionView(model:model)); panel = p
 }
 panel?.orderFrontRegardless()
 }
 func hide() { panel?.orderOut(nil) }
 func mainWindow() { NSApp.activate(ignoringOtherApps:true); NSApp.windows.first(where:{$0.title == "灵语龙·本地版"})?.makeKeyAndOrderFront(nil) }
}
struct CaptionView:View {
 @ObservedObject var model:Model
 var body:some View {
 Text(model.captionText).font(.system(size:CGFloat(model.captionSize),weight:.semibold)).foregroundStyle(.white).multilineTextAlignment(.center).lineLimit(4).minimumScaleFactor(0.65).frame(maxWidth:.infinity,maxHeight:.infinity).padding(.horizontal,24).padding(.vertical,14).background(.black.opacity(0.68)).clipShape(RoundedRectangle(cornerRadius:18)).onTapGesture(count:2) { CaptionController.shared.mainWindow() }.help("拖动可移动字幕；双击返回主窗口")
 }
}
