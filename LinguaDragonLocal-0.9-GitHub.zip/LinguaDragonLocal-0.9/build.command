#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p .build
clang -c Vendor/qrcodegen.c -o .build/qrcodegen.o
clang -c Vendor/phone_qr.c -o .build/phone_qr.o
swiftc -module-cache-path .build/ModuleCache -parse-as-library -swift-version 5 -target arm64-apple-macosx26.0 Source/*.swift .build/qrcodegen.o .build/phone_qr.o -o LinguaDragonLocal.app/Contents/MacOS/LinguaDragon
codesign --force --deep --sign - LinguaDragonLocal.app
print '构建完成：LinguaDragonLocal.app'
